
/*
    Programado por Heesler Estuardo López Barraza
  
*/

package me.parzibyte.sistemaventasspringboot;

import org.springframework.data.repository.CrudRepository;

public interface VentasRepository extends CrudRepository<Venta, Integer> {
}
